from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uuid

# Initialize FastAPI app
app = FastAPI(
    title="Yaqez Chrome Extension Backend",
    description="Backend API for Yaqez security extension",
    version="1.0.0"
)

# ============================================================================
# CORS Configuration - Critical for Chrome Extension
# ============================================================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8000",
        "chrome-extension://*",  # Allows any Chrome extension
    ],
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
    expose_headers=["*"]  # Expose all response headers
)

# ============================================================================
# Pydantic Models for Request/Response
# ============================================================================

class AssistantRequest(BaseModel):
    """Request model for /assistant endpoint"""
    session_id: str
    message: str

class AssistantResponse(BaseModel):
    """Response model for /assistant endpoint"""
    reply: str
    session_id: str

class AnalysisResponse(BaseModel):
    """Response model for /analyze/all endpoint"""
    text_result: Optional[dict] = None
    url_result: Optional[dict] = None
    logo_result: Optional[dict] = None
    final_decision: str  # "safe", "suspicious", "dangerous"
    risk_score: float
    explanation: str
    session_id: str

class SafeLinkResponse(BaseModel):
    """Response model for /safe-link endpoint"""
    url: str
    session_id: str

class ChatHistoryItem(BaseModel):
    """Individual chat history item"""
    id: int
    user_message: str
    bot_response: str
    timestamp: str

class ChatHistoryResponse(BaseModel):
    """Response model for /chat/history endpoint"""
    history: list[ChatHistoryItem]
    total: int
    session_id: str

# ============================================================================
# In-Memory Storage (Replace with database in production)
# ============================================================================

# Store chat history: {session_id: [messages]}
chat_storage = {}

# Store safe links: {session_id: safe_url}
safe_links = {}

# Counter for message IDs
message_counter = 0

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/")
async def root():
    """Root endpoint - health check"""
    return {
        "status": "operational",
        "message": "Yaqez Backend API",
        "version": "1.0.0"
    }

@app.post("/analyze/all", response_model=AnalysisResponse)
async def analyze_all(
    message: Optional[str] = Form(None),
    url: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    session_id: str = Form(default="default")
):
    """
    Analyze text, URL, and/or file (logo) for security threats
    
    Accepts:
    - message (text): Text content to analyze
    - url: URL to check for phishing/malicious content
    - file: Image file containing logo to verify
    - session_id: Session identifier
    """
    try:
        # Initialize result structure
        text_result = None
        url_result = None
        logo_result = None
        
        # Analyze text if provided
        if message:
            text_result = {
                "is_fraud": False,
                "reason": "Text appears safe",
                "confidence": 0.95
            }
            # Add basic keyword detection
            fraud_keywords = ["تنبيه عاجل", "حساب موقوف", "تفعيل فوري", "اضغط هنا", "urgent", "suspended"]
            if any(keyword in message.lower() for keyword in fraud_keywords):
                text_result = {
                    "is_fraud": True,
                    "reason": "Contains common phishing phrases",
                    "confidence": 0.85
                }
        
        # Analyze URL if provided
        if url:
            url_result = {
                "safe": True,
                "reason": "URL appears legitimate",
                "confidence": 0.90
            }
            # Basic URL safety check
            suspicious_patterns = ["bit.ly", "tinyurl", "suspicious", "login", "verify"]
            if any(pattern in url.lower() for pattern in suspicious_patterns):
                url_result = {
                    "safe": False,
                    "reason": "URL contains suspicious patterns",
                    "confidence": 0.80
                }
        
        # Analyze logo if provided
        if file:
            # Read file content
            contents = await file.read()
            logo_result = {
                "is_suspicious": False,
                "reason": "Logo appears legitimate",
                "confidence": 0.88,
                "filename": file.filename
            }
        
        # Calculate overall risk score
        risk_factors = []
        if text_result and text_result.get("is_fraud"):
            risk_factors.append(0.4)
        if url_result and not url_result.get("safe"):
            risk_factors.append(0.4)
        if logo_result and logo_result.get("is_suspicious"):
            risk_factors.append(0.3)
        
        risk_score = sum(risk_factors) if risk_factors else 0.0
        
        # Determine final decision
        if risk_score >= 0.7:
            final_decision = "dangerous"
            explanation = "Multiple security threats detected. Do not proceed!"
        elif risk_score >= 0.3:
            final_decision = "suspicious"
            explanation = "Some concerning indicators found. Exercise caution."
        else:
            final_decision = "safe"
            explanation = "No significant threats detected."
        
        return AnalysisResponse(
            text_result=text_result,
            url_result=url_result,
            logo_result=logo_result,
            final_decision=final_decision,
            risk_score=risk_score,
            explanation=explanation,
            session_id=session_id
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.post("/assistant", response_model=AssistantResponse)
async def assistant_chat(request: AssistantRequest):
    """
    Conversational assistant endpoint
    
    Receives user messages and provides helpful responses about security
    """
    try:
        user_message = request.message.lower()
        
        # Simple response logic based on keywords
        if "مساعدة" in user_message or "help" in user_message:
            reply = "مرحباً! أنا هنا للمساعدة في حمايتك من الاحتيال. يمكنك إرسال رسائل أو روابط أو صور للتحليل."
        elif "كيف" in user_message or "how" in user_message:
            reply = "يمكنني تحليل الرسائل النصية والروابط والشعارات للكشف عن محاولات الاحتيال. فقط أرسل المحتوى المشبوه وسأقوم بفحصه."
        elif "آمن" in user_message or "safe" in user_message:
            reply = "للتأكد من أن رسالة أو رابط آمن، أرسله لي وسأقوم بتحليله باستخدام أنظمة الكشف المتقدمة."
        elif "احتيال" in user_message or "phishing" in user_message:
            reply = "الاحتيال الإلكتروني شائع! احترس من الرسائل التي تطلب معلومات شخصية أو تحتوي على روابط مشبوهة."
        else:
            reply = "شكراً على رسالتك. كيف يمكنني مساعدتك اليوم؟ يمكنك أن تسأل عن كيفية اكتشاف الاحتيال أو إرسال محتوى للتحليل."
        
        # Store in chat history
        if request.session_id not in chat_storage:
            chat_storage[request.session_id] = []
        
        global message_counter
        message_counter += 1
        
        chat_storage[request.session_id].append({
            "id": message_counter,
            "user_message": request.message,
            "bot_response": reply,
            "timestamp": "2025-12-12T12:00:00Z"  # Use actual timestamp in production
        })
        
        return AssistantResponse(
            reply=reply,
            session_id=request.session_id
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Assistant error: {str(e)}")

@app.get("/safe-link", response_model=SafeLinkResponse)
async def get_safe_link(session_id: str = Query(default="default")):
    """
    Retrieve the safe/verified URL for the given session
    
    This endpoint provides a legitimate URL to redirect users to
    when they encounter a blocked malicious site
    """
    try:
        # Check if we have a stored safe link for this session
        if session_id in safe_links:
            safe_url = safe_links[session_id]
        else:
            # Default safe URL (Saudi government portal)
            safe_url = "https://www.absher.sa"
            # Store it for future reference
            safe_links[session_id] = safe_url
        
        return SafeLinkResponse(
            url=safe_url,
            session_id=session_id
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve safe link: {str(e)}")

@app.get("/chat/history", response_model=ChatHistoryResponse)
async def get_chat_history(
    session_id: Optional[str] = Query(None),
    limit: int = Query(default=50, ge=1, le=200)
):
    """
    Retrieve chat history for a session
    
    Parameters:
    - session_id: Specific session to retrieve (if None, returns all)
    - limit: Maximum number of messages to return
    """
    try:
        if session_id and session_id in chat_storage:
            # Return history for specific session
            history = chat_storage[session_id][-limit:]
            total = len(chat_storage[session_id])
        elif session_id is None:
            # Return all history from all sessions
            all_messages = []
            for messages in chat_storage.values():
                all_messages.extend(messages)
            history = all_messages[-limit:]
            total = len(all_messages)
        else:
            # Session not found
            history = []
            total = 0
        
        # Convert to response format
        history_items = [
            ChatHistoryItem(
                id=msg["id"],
                user_message=msg["user_message"],
                bot_response=msg["bot_response"],
                timestamp=msg["timestamp"]
            )
            for msg in history
        ]
        
        return ChatHistoryResponse(
            history=history_items,
            total=total,
            session_id=session_id or "all"
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve history: {str(e)}")

# ============================================================================
# Additional utility endpoints
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "sessions_active": len(chat_storage),
        "messages_total": sum(len(msgs) for msgs in chat_storage.values())
    }

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Yaqez Backend API...")
    print("📡 Server will be available at: http://localhost:8000")
    print("📚 API documentation at: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
from sqlalchemy.orm import Session
from datetime import datetime
import json
from .models import ChatHistory, LogoScan, TextScan, URLScan, PhishingAttempt, UserSession

class Repository:
    def __init__(self, db: Session):
        self.db = db
    
    def save_message(self, session_id: str, user_message: str, bot_response: str):
        """Save chat message to history"""
        chat_entry = ChatHistory(
            session_id=session_id,
            user_message=user_message,
            bot_response=bot_response
        )
        self.db.add(chat_entry)
        self.db.commit()
        self.db.refresh(chat_entry)
        return chat_entry
    
    def save_logo_scan(self, session_id: str, image_path: str, result_json: dict):
        """Save logo scan results"""
        logo_scan = LogoScan(
            session_id=session_id,
            image_path=image_path,
            result=json.dumps(result_json),
            is_suspicious=result_json.get("is_suspicious", False),
            confidence=result_json.get("confidence", 0.0)
        )
        self.db.add(logo_scan)
        self.db.commit()
        self.db.refresh(logo_scan)
        return logo_scan
    
    def save_text_scan(self, session_id: str, text: str, result_json: dict):
        """Save text scan results"""
        text_scan = TextScan(
            session_id=session_id,
            text_content=text,
            result=json.dumps(result_json),
            is_fraud=result_json.get("is_fraud", False),
            confidence=result_json.get("confidence", 0.0)
        )
        self.db.add(text_scan)
        self.db.commit()
        self.db.refresh(text_scan)
        return text_scan
    
    def save_url_scan(self, session_id: str, url: str, result_json: dict):
        """Save URL scan results"""
        url_scan = URLScan(
            session_id=session_id,
            url=url,
            result=json.dumps(result_json),
            is_malicious=not result_json.get("safe", True),
            confidence=result_json.get("confidence", 0.0)
        )
        self.db.add(url_scan)
        self.db.commit()
        self.db.refresh(url_scan)
        return url_scan
    
    def save_phishing_attempt(self, session_id: str, source_type: str, content: str, 
                            detection_reason: str, confidence: float):
        """Save detected phishing attempt"""
        phishing = PhishingAttempt(
            session_id=session_id,
            source_type=source_type,
            content=content,
            detection_reason=detection_reason,
            confidence=confidence
        )
        self.db.add(phishing)
        self.db.commit()
        self.db.refresh(phishing)
        return phishing
    
    def get_chat_history(self, session_id: str = None, limit: int = 50):
        """Get chat history"""
        query = self.db.query(ChatHistory)
        if session_id:
            query = query.filter(ChatHistory.session_id == session_id)
        return query.order_by(ChatHistory.created_at.desc()).limit(limit).all()
    
    def create_or_update_session(self, session_id: str):
        """Create or update user session"""
        session = self.db.query(UserSession).filter(UserSession.session_id == session_id).first()
        if session:
            session.last_activity = datetime.utcnow()
        else:
            session = UserSession(session_id=session_id)
            self.db.add(session)
        self.db.commit()
        self.db.refresh(session)
        return session
    
    def get_recent_scans(self, session_id: str = None, limit: int = 10):
        """Get recent scans of all types"""
        results = {
            "logo_scans": [],
            "text_scans": [],
            "url_scans": []
        }
        
        if session_id:
            results["logo_scans"] = self.db.query(LogoScan).filter(
                LogoScan.session_id == session_id
            ).order_by(LogoScan.created_at.desc()).limit(limit).all()
            
            results["text_scans"] = self.db.query(TextScan).filter(
                TextScan.session_id == session_id
            ).order_by(TextScan.created_at.desc()).limit(limit).all()
            
            results["url_scans"] = self.db.query(URLScan).filter(
                URLScan.session_id == session_id
            ).order_by(URLScan.created_at.desc()).limit(limit).all()
        
        return results
#!/bin/bash

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}🛑 Stopping Yaqith Services...${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"

PROJECT_DIR=$(pwd)
BACKEND_PORT=8000
FRONTEND_PORT=8080

# Function to print status
print_status() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✓${NC} $2"
    else
        echo -e "${RED}✗${NC} $2"
    fi
}

# Kill Backend
echo -e "${CYAN}Stopping Backend...${NC}"
OLD_BACKEND=$(lsof -ti:$BACKEND_PORT 2>/dev/null)
if [ ! -z "$OLD_BACKEND" ]; then
    kill -9 $OLD_BACKEND 2>/dev/null
    print_status 0 "Backend stopped (PID: $OLD_BACKEND)"
else
    print_status 1 "Backend not running"
fi

# Kill Frontend
echo -e "${CYAN}Stopping Frontend...${NC}"
OLD_FRONTEND=$(lsof -ti:$FRONTEND_PORT 2>/dev/null)
if [ ! -z "$OLD_FRONTEND" ]; then
    kill -9 $OLD_FRONTEND 2>/dev/null
    print_status 0 "Frontend stopped (PID: $OLD_FRONTEND)"
else
    print_status 1 "Frontend not running"
fi

# Kill any Python processes from this project
echo -e "${CYAN}Cleaning up Python processes...${NC}"
pkill -f "uvicorn" 2>/dev/null && print_status 0 "Killed uvicorn processes"

# Remove PID file
if [ -f "$PROJECT_DIR/.pids" ]; then
    rm "$PROJECT_DIR/.pids"
    print_status 0 "Cleaned up PID file"
fi

echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✅ All services stopped!${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
"""
Lightning AI App for Yaqith - v2.6.0 Compatible
Install: pip install "lightning[app]>=2.6.0" fastapi uvicorn python-multipart
Run locally: lightning run app app.py
Run on cloud: lightning run app app.py --cloud
"""

import lightning as L
from lightning.app import CloudCompute
from pathlib import Path
import os


class YaqithFrontendServer(L.LightningWork):
    """Serve the Yaqith Frontend with FastAPI"""
    
    def __init__(self):
        super().__init__(cloud_compute=CloudCompute("cpu"))
    
    def run(self):
        from fastapi import FastAPI
        from fastapi.responses import HTMLResponse
        from fastapi.middleware.cors import CORSMiddleware
        import uvicorn
        
        app = FastAPI(
            title="Yaqith Frontend",
            description="Multi-agent system frontend for safety analysis",
            version="1.0.0"
        )
        
        # CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # HTML Frontend
        HTML_CONTENT = """
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>يقظ - نظام السلامة</title>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      direction: rtl;
      font-family: 'Tajawal', sans-serif;
      background: #0e1e49;
      color: #f0f0f0;
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
    }

    .logo-img {
      width: 120px;
      height: 120px;
      margin-bottom: 20px;
      filter: drop-shadow(0 0 20px rgba(255, 255, 255, 0.2));
    }

    h1 {
      color: #4CD7A8;
      margin-bottom: 10px;
      font-size: 28px;
    }

    .subtitle {
      color: #b0b0b0;
      font-size: 14px;
    }

    .analysis-section {
      background: #18254f;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #4CD7A8;
      font-weight: 500;
      font-size: 14px;
    }

    input[type="text"],
    input[type="url"],
    textarea,
    input[type="file"] {
      width: 100%;
      padding: 12px;
      background: #0e1e49;
      border: 1px solid #4CD7A8;
      border-radius: 6px;
      color: #f0f0f0;
      font-family: 'Tajawal', sans-serif;
      font-size: 14px;
    }

    textarea {
      resize: vertical;
      min-height: 80px;
    }

    .button-group {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }

    button {
      flex: 1;
      padding: 12px;
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      font-family: 'Tajawal', sans-serif;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .btn-primary {
      background: #4CD7A8;
      color: #0e1e49;
    }

    .btn-primary:hover {
      background: #36b38a;
      transform: translateY(-2px);
    }

    .btn-primary:disabled {
      background: #666;
      cursor: not-allowed;
    }

    .btn-secondary {
      background: transparent;
      border: 1px solid #4CD7A8;
      color: #4CD7A8;
    }

    .btn-secondary:hover {
      background: rgba(76, 215, 168, 0.1);
    }

    .result-box {
      background: #18254f;
      border-radius: 12px;
      padding: 20px;
      margin-top: 20px;
      border-right: 4px solid #4CD7A8;
      display: none;
    }

    .result-box.show {
      display: block;
      animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .result-box.danger {
      border-right-color: #EE404C;
    }

    .result-box.warning {
      border-right-color: #FFA500;
    }

    .result-box.safe {
      border-right-color: #4CD7A8;
    }

    .result-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 15px;
      flex-wrap: wrap;
      gap: 10px;
    }

    .result-status {
      font-size: 24px;
      font-weight: 700;
    }

    .risk-score {
      background: rgba(76, 215, 168, 0.2);
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
    }

    .risk-score.high {
      background: rgba(238, 64, 76, 0.2);
      color: #EE404C;
    }

    .result-details {
      margin-top: 15px;
      padding: 12px;
      background: rgba(0, 0, 0, 0.2);
      border-radius: 6px;
      font-size: 13px;
      line-height: 1.6;
    }

    .tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      border-bottom: 2px solid #4CD7A8;
      overflow-x: auto;
    }

    .tab {
      padding: 12px 16px;
      background: none;
      border: none;
      color: #b0b0b0;
      cursor: pointer;
      font-family: 'Tajawal', sans-serif;
      font-weight: 500;
      border-bottom: 3px solid transparent;
      margin-bottom: -2px;
      transition: all 0.3s ease;
      white-space: nowrap;
    }

    .tab.active {
      color: #4CD7A8;
      border-bottom-color: #4CD7A8;
    }

    .tab-content {
      display: none;
    }

    .tab-content.active {
      display: block;
    }

    .chat-box {
      background: #18254f;
      border-radius: 12px;
      padding: 16px;
      max-height: 400px;
      overflow-y: auto;
      margin-bottom: 12px;
    }

    .chat-message {
      margin-bottom: 12px;
      padding: 10px 12px;
      border-radius: 6px;
      font-size: 13px;
      word-wrap: break-word;
    }

    .chat-message.user {
      background: #4CD7A8;
      color: #0e1e49;
      text-align: left;
      max-width: 80%;
      margin-right: auto;
    }

    .chat-message.bot {
      background: #2a3a5f;
      color: #f0f0f0;
      max-width: 80%;
      margin-left: auto;
      text-align: right;
    }

    .loading-spinner {
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 3px solid rgba(76, 215, 168, 0.2);
      border-top-color: #4CD7A8;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .error {
      background: rgba(238, 64, 76, 0.1);
      border: 1px solid #EE404C;
      border-radius: 6px;
      padding: 12px;
      color: #EE404C;
      font-size: 13px;
      margin-top: 10px;
      display: none;
    }

    .error.show {
      display: block;
    }

    .info-box {
      background: rgba(76, 215, 168, 0.1);
      border: 1px solid #4CD7A8;
      border-radius: 6px;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 13px;
      color: #4CD7A8;
    }

    .backend-config {
      background: rgba(255, 165, 0, 0.1);
      border: 1px solid #FFA500;
      border-radius: 6px;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 12px;
      color: #FFA500;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 120'%3E%3Ccircle cx='60' cy='60' r='55' fill='%234CD7A8' opacity='0.1' stroke='%234CD7A8' stroke-width='2'/%3E%3Ctext x='50%' y='50%' font-size='60' font-weight='bold' fill='%234CD7A8' text-anchor='middle' dy='.3em'%3E⚡%3C/text%3E%3C/svg%3E" alt="Yaqith Logo" class="logo-img">
      <h1>يقظ - نظام السلامة</h1>
      <p class="subtitle">نظام متقدم لكشف الاحتيال والتصيد الاحتيالي</p>
    </div>

    <div class="backend-config" id="backendStatus">
      🔄 جاري اختبار اتصال الخادم الخلفي...
    </div>

    <div class="tabs">
      <button class="tab active" data-tab="analysis">تحليل</button>
      <button class="tab" data-tab="chat">محادثة</button>
      <button class="tab" data-tab="history">السجل</button>
    </div>

    <div id="analysis" class="tab-content active">
      <div class="analysis-section">
        <h2 style="color: #4CD7A8; margin-bottom: 20px; font-size: 18px;">تحليل النصوص والروابط والصور</h2>

        <div class="form-group">
          <label for="analysisText">النص</label>
          <textarea id="analysisText" placeholder="أدخل النص الذي تريد تحليله..."></textarea>
        </div>

        <div class="form-group">
          <label for="analysisUrl">الرابط (URL)</label>
          <input type="url" id="analysisUrl" placeholder="https://example.com">
        </div>

        <div class="form-group">
          <label for="analysisFile">الصورة</label>
          <input type="file" id="analysisFile" accept="image/*">
        </div>

        <div class="button-group">
          <button class="btn-primary" onclick="analyzeAll()">تحليل الكل</button>
          <button class="btn-secondary" onclick="clearAnalysis()">مسح</button>
        </div>

        <div class="error" id="analysisError"></div>
        <div id="resultsContainer"></div>
      </div>
    </div>

    <div id="chat" class="tab-content">
      <div class="analysis-section">
        <h2 style="color: #4CD7A8; margin-bottom: 20px; font-size: 18px;">محادثة مع مساعد السلامة</h2>

        <div class="chat-box" id="chatBox"></div>

        <div class="form-group">
          <label for="chatInput">رسالتك</label>
          <textarea id="chatInput" placeholder="أرسل رسالة..."></textarea>
        </div>

        <div class="form-group">
          <label for="chatFile">صورة (اختياري)</label>
          <input type="file" id="chatFile" accept="image/*">
        </div>

        <div class="button-group">
          <button class="btn-primary" onclick="sendChat()">إرسال</button>
          <button class="btn-secondary" onclick="clearChat()">مسح المحادثة</button>
        </div>

        <div class="error" id="chatError"></div>
      </div>
    </div>

    <div id="history" class="tab-content">
      <div class="analysis-section">
        <h2 style="color: #4CD7A8; margin-bottom: 20px; font-size: 18px;">سجل المحادثات</h2>
        <div id="historyContainer" style="min-height: 200px;"></div>
        <button class="btn-secondary" onclick="loadHistory()" style="width: 100%; margin-top: 15px;">تحديث السجل</button>
      </div>
    </div>
  </div>

  <script>
    // Auto-detect backend URL
    let API_URL = localStorage.getItem('backendUrl') || 'http://localhost:8000';
    let sessionId = localStorage.getItem('sessionId') || 'session_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('sessionId', sessionId);

    // Test backend connection
    async function testBackendConnection() {
      const statusEl = document.getElementById('backendStatus');
      try {
        const response = await fetch(API_URL + '/health', { method: 'GET' });
        if (response.ok) {
          statusEl.innerHTML = '✅ الخادم الخلفي متصل بنجاح على: ' + API_URL;
          statusEl.style.background = 'rgba(76, 215, 168, 0.1)';
          statusEl.style.borderColor = '#4CD7A8';
          statusEl.style.color = '#4CD7A8';
        } else {
          throw new Error('Server returned: ' + response.status);
        }
      } catch (error) {
        statusEl.innerHTML = '❌ خطأ في الاتصال بالخادم الخلفي<br>URL: ' + API_URL + '<br>Error: ' + error.message + '<br><button onclick="promptBackendUrl()" style="margin-top: 10px; padding: 5px 10px; background: #FFA500; border: none; color: white; border-radius: 4px; cursor: pointer;">تغيير الخادم</button>';
        statusEl.style.background = 'rgba(238, 64, 76, 0.1)';
        statusEl.style.borderColor = '#EE404C';
        statusEl.style.color = '#EE404C';
      }
    }

    function promptBackendUrl() {
      const url = prompt('أدخل عنوان الخادم الخلفي:', API_URL);
      if (url) {
        API_URL = url;
        localStorage.setItem('backendUrl', url);
        testBackendConnection();
      }
    }

    testBackendConnection();

    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab).classList.add('active');
      });
    });

    async function analyzeAll() {
      const text = document.getElementById('analysisText').value;
      const url = document.getElementById('analysisUrl').value;
      const file = document.getElementById('analysisFile').files[0];
      const errorDiv = document.getElementById('analysisError');

      if (!text && !url && !file) {
        showError(errorDiv, 'يرجى إدخال نص أو رابط أو اختيار صورة');
        return;
      }

      try {
        errorDiv.classList.remove('show');
        const resultsDiv = document.getElementById('resultsContainer');
        resultsDiv.innerHTML = '<div style="text-align: center; padding: 20px;"><div class="loading-spinner"></div><p style="color: #b0b0b0; margin-top: 10px;">جاري التحليل...</p></div>';

        const formData = new FormData();
        if (text) formData.append('text', text);
        if (url) formData.append('url', url);
        if (file) formData.append('file', file);
        formData.append('session_id', sessionId);

        const response = await fetch(API_URL + '/analyze/all', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) throw new Error('فشل التحليل: ' + response.status);

        const result = await response.json();
        displayResults(result, resultsDiv);
      } catch (error) {
        showError(errorDiv, '❌ خطأ: ' + error.message);
        console.error(error);
      }
    }

    function displayResults(result, container) {
      const decision = result.final_decision || 'unknown';
      const riskScore = result.risk_score || 0;
      const explanation = result.explanation || 'لا توجد معلومات إضافية';

      let icon = '❓';
      let status = 'غير معروف';
      let statusClass = '';

      if (decision === 'safe') {
        icon = '✅';
        status = 'آمن';
        statusClass = 'safe';
      } else if (decision === 'suspicious') {
        icon = '⚠️';
        status = 'مشبوه';
        statusClass = 'warning';
      } else if (decision === 'dangerous') {
        icon = '🚨';
        status = 'خطر';
        statusClass = 'danger';
      }

      let html = `<div class="result-box show ${statusClass}"><div class="result-header"><div class="result-status">${icon} ${status}</div><div class="risk-score ${riskScore > 0.5 ? 'high' : ''}">خطورة: ${Math.round(riskScore * 100)}%</div></div><div class="result-details"><div><strong>التفسير:</strong><br>${explanation}</div>`;

      if (result.text_result) {
        html += `<div style="margin-top: 10px;"><strong>النص:</strong> ${result.text_result.is_fraud ? '🚫' : '✅'} ${result.text_result.reason || ''}</div>`;
      }

      if (result.url_result) {
        html += `<div style="margin-top: 10px;"><strong>الرابط:</strong> ${result.url_result.safe ? '✅' : '🚫'} ${result.url_result.reason || ''}</div>`;
      }

      if (result.logo_result) {
        html += `<div style="margin-top: 10px;"><strong>الشعار:</strong> ${result.logo_result.is_suspicious ? '⚠️' : '✅'} ${result.logo_result.reason || ''}</div>`;
      }

      html += `</div></div>`;
      container.innerHTML = html;
    }

    async function sendChat() {
      const message = document.getElementById('chatInput').value;
      const file = document.getElementById('chatFile').files[0];
      const errorDiv = document.getElementById('chatError');
      const chatBox = document.getElementById('chatBox');

      if (!message && !file) {
        showError(errorDiv, 'يرجى إدخال رسالة أو اختيار صورة');
        return;
      }

      try {
        errorDiv.classList.remove('show');
        
        const userMsg = document.createElement('div');
        userMsg.className = 'chat-message user';
        userMsg.textContent = message || (file ? 'صورة: ' + file.name : '');
        chatBox.appendChild(userMsg);
        chatBox.scrollTop = chatBox.scrollHeight;

        const formData = new FormData();
        formData.append('message', message);
        if (file) formData.append('file', file);
        formData.append('session_id', sessionId);

        const response = await fetch(API_URL + '/chat', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) throw new Error('فشل الاتصال: ' + response.status);

        const result = await response.json();

        const botMsg = document.createElement('div');
        botMsg.className = 'chat-message bot';
        botMsg.textContent = result.message;
        chatBox.appendChild(botMsg);
        chatBox.scrollTop = chatBox.scrollHeight;

        document.getElementById('chatInput').value = '';
        document.getElementById('chatFile').value = '';
      } catch (error) {
        showError(errorDiv, '❌ خطأ: ' + error.message);
        console.error(error);
      }
    }

    async function loadHistory() {
      const container = document.getElementById('historyContainer');
      try {
        container.innerHTML = '<div style="text-align: center;"><div class="loading-spinner"></div></div>';
        const response = await fetch(API_URL + '/chat/history?session_id=' + sessionId + '&limit=50');
        if (!response.ok) throw new Error('فشل تحميل السجل');
        const result = await response.json();
        const history = result.history || [];

        if (history.length === 0) {
          container.innerHTML = '<p style="color: #b0b0b0; text-align: center;">لا توجد محادثات بعد</p>';
          return;
        }

        let html = '';
        history.forEach(item => {
          const date = new Date(item.created_at).toLocaleString('ar-SA');
          html += `<div style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #4CD7A8;"><div style="color: #4CD7A8; font-size: 12px; margin-bottom: 5px;">${date}</div><div style="background: #0e1e49; padding: 10px; border-radius: 6px; margin-bottom: 8px;"><strong>أنت:</strong> ${item.user_message}</div><div style="background: #2a3a5f; padding: 10px; border-radius: 6px;"><strong>المساعد:</strong> ${item.bot_response}</div></div>`;
        });
        container.innerHTML = html;
      } catch (error) {
        container.innerHTML = '<p style="color: #EE404C;">❌ خطأ: ' + error.message + '</p>';
      }
    }

    function clearAnalysis() {
      document.getElementById('analysisText').value = '';
      document.getElementById('analysisUrl').value = '';
      document.getElementById('analysisFile').value = '';
      document.getElementById('resultsContainer').innerHTML = '';
    }

    function clearChat() {
      document.getElementById('chatBox').innerHTML = '';
      document.getElementById('chatInput').value = '';
      document.getElementById('chatFile').value = '';
    }

    function showError(element, message) {
      element.innerHTML = message;
      element.classList.add('show');
    }

    document.querySelectorAll('.tab')[2].addEventListener('click', loadHistory);
  </script>
</body>
</html>
        """
        
        @app.get("/", response_class=HTMLResponse)
        async def serve_frontend():
            return HTML_CONTENT
        
        @app.get("/health")
        async def health():
            return {"status": "healthy", "service": "yaqith-frontend"}
        
        # Run on port 8080
        uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")


class YaqithApp(L.LightningApp):
    """Main Lightning App for Yaqith"""
    
    def __init__(self):
        super().__init__()
        self.frontend = YaqithFrontendServer()
    
    def configure_layout(self):
        """Configure the app layout"""
        return {"Frontend": self.frontend}


if __name__ == "__main__":
    app = YaqithApp()
from langgraph.graph import StateGraph, END
from typing import Dict, Any, TypedDict, Optional
from app.agents.logo_agent import LogoAgent
from app.agents.text_agent import TextAgent
from app.agents.url_agent import UrlAgent
from app.agents.coordinator import CoordinatorAgent

class AnalysisState(TypedDict, total=False):
    """State object for the analysis workflow"""
    text: Optional[str]
    url: Optional[str]
    image: Optional[Any]
    session_id: str
    logo_result: Optional[Dict[str, Any]]
    text_result: Optional[Dict[str, Any]]
    url_result: Optional[Dict[str, Any]]
    risk_score: Optional[float]
    final_decision: Optional[str]
    explanation: Optional[str]
    agents_called: Optional[list]

class MultiAgentWorkflow:
    """
    LangGraph workflow that orchestrates all agents
    """
    
    def __init__(self):
        print("Initializing Multi-Agent Workflow...")
        
        # Try loading AI models, fall back to rule-based if needed
        try:
            from app.agents.logo_agent import LogoAgent
            self.logo_agent = LogoAgent()
            print("✅ Logo Agent loaded (AI model)")
        except Exception as e:
            print(f"⚠️  Logo Agent AI model failed, using fallback: {e}")
            from app.agents.fallback_models import FallbackLogoAgent
            self.logo_agent = FallbackLogoAgent()
            print("✅ Logo Agent loaded (fallback)")
        
        try:
            from app.agents.text_agent import TextAgent
            self.text_agent = TextAgent()
            print("✅ Text Agent loaded (AI model)")
        except Exception as e:
            print(f"⚠️  Text Agent AI model failed, using fallback: {e}")
            from app.agents.fallback_models import FallbackTextAgent
            self.text_agent = FallbackTextAgent()
            print("✅ Text Agent loaded (fallback)")
        
        try:
            from app.agents.url_agent import UrlAgent
            self.url_agent = UrlAgent()
            print("✅ URL Agent loaded (AI model)")
        except Exception as e:
            print(f"⚠️  URL Agent AI model failed, using fallback: {e}")
            from app.agents.fallback_models import FallbackUrlAgent
            self.url_agent = FallbackUrlAgent()
            print("✅ URL Agent loaded (fallback)")
        
        self.coordinator = CoordinatorAgent()
        self.graph = self._build_graph()
        print("✅ Workflow graph built successfully")
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow"""
        
        # Create graph
        workflow = StateGraph(AnalysisState)
        
        # Add nodes
        workflow.add_node("coordinator_pre", self._coordinator_pre)
        workflow.add_node("logo_agent", self.logo_agent)
        workflow.add_node("text_agent", self.text_agent)
        workflow.add_node("url_agent", self.url_agent)
        workflow.add_node("coordinator_post", self.coordinator)
        
        # Add edges
        workflow.set_entry_point("coordinator_pre")
        
        # Conditional routing based on what needs to be analyzed
        workflow.add_conditional_edges(
            "coordinator_pre",
            self._route_to_agents,
            {
                "logo_only": "logo_agent",
                "text_only": "text_agent",
                "url_only": "url_agent",
                "logo_text": "logo_agent",
                "logo_url": "logo_agent",
                "text_url": "text_agent",
                "all": "logo_agent",
                "none": "coordinator_post"
            }
        )
        
        # After logo agent, check what else needs to run
        workflow.add_conditional_edges(
            "logo_agent",
            self._after_logo,
            {
                "text": "text_agent",
                "url": "url_agent",
                "done": "coordinator_post"
            }
        )
        
        # After text agent, check if URL needs to run
        workflow.add_conditional_edges(
            "text_agent",
            self._after_text,
            {
                "url": "url_agent",
                "done": "coordinator_post"
            }
        )
        
        # URL agent always goes to coordinator
        workflow.add_edge("url_agent", "coordinator_post")
        
        # Coordinator post is the end
        workflow.add_edge("coordinator_post", END)
        
        return workflow.compile()
    
    def _coordinator_pre(self, state: AnalysisState) -> AnalysisState:
        """Pre-processing coordinator step"""
        return state
    
    def _route_to_agents(self, state: AnalysisState) -> str:
        """Determine which agents to call"""
        has_text = bool(state.get("text"))
        has_url = bool(state.get("url"))
        has_image = bool(state.get("image"))
        
        if has_image and has_text and has_url:
            return "all"
        elif has_image and has_text:
            return "logo_text"
        elif has_image and has_url:
            return "logo_url"
        elif has_text and has_url:
            return "text_url"
        elif has_image:
            return "logo_only"
        elif has_text:
            return "text_only"
        elif has_url:
            return "url_only"
        else:
            return "none"
    
    def _after_logo(self, state: AnalysisState) -> str:
        """Determine next step after logo agent"""
        if state.get("text"):
            return "text"
        elif state.get("url"):
            return "url"
        else:
            return "done"
    
    def _after_text(self, state: AnalysisState) -> str:
        """Determine next step after text agent"""
        if state.get("url"):
            return "url"
        else:
            return "done"
    
    async def analyze(self, 
                     text: Optional[str] = None,
                     url: Optional[str] = None,
                     image: Optional[Any] = None,
                     session_id: str = "default") -> Dict[str, Any]:
        """
        Run the complete analysis workflow
        
        Args:
            text: Text to analyze
            url: URL to check
            image: Image to analyze
            session_id: Session identifier
            
        Returns:
            Complete analysis results
        """
        initial_state = AnalysisState(
            text=text,
            url=url,
            image=image,
            session_id=session_id
        )
        
        # Run the graph
        result = self.graph.invoke(initial_state)
        
        return result
    
    def analyze_sync(self,
                    text: Optional[str] = None,
                    url: Optional[str] = None,
                    image: Optional[Any] = None,
                    session_id: str = "default") -> Dict[str, Any]:
        """
        Synchronous version of analyze
        """
        initial_state = AnalysisState(
            text=text,
            url=url,
            image=image,
            session_id=session_id
        )
        
        # Run the graph
        result = self.graph.invoke(initial_state)
        
        return result
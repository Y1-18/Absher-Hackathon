from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from typing import Dict, Any

class TextAgent:
    def __init__(self):
        self.model_name = "Yasser18/qwen-arabic-fraud-detector"
        self.tokenizer = None
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._load_model()
    
    def _load_model(self):
        """Load the Arabic fraud detection model"""
        try:
            print(f"Loading Text Fraud Detection Model: {self.model_name}")
            
            # Try loading with trust_remote_code and use_fast=False as fallback
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(
                    self.model_name,
                    trust_remote_code=True,
                    use_fast=True
                )
            except Exception as e1:
                print(f"Fast tokenizer failed, trying slow tokenizer: {e1}")
                try:
                    self.tokenizer = AutoTokenizer.from_pretrained(
                        self.model_name,
                        trust_remote_code=True,
                        use_fast=False
                    )
                except Exception as e2:
                    print(f"Slow tokenizer failed, using base Qwen2 tokenizer: {e2}")
                    # Fallback to base Qwen2 tokenizer
                    self.tokenizer = AutoTokenizer.from_pretrained(
                        "Qwen/Qwen2-0.5B",
                        trust_remote_code=True
                    )
            
            self.model = AutoModelForSequenceClassification.from_pretrained(
                self.model_name,
                trust_remote_code=True
            )
            self.model.to(self.device)
            self.model.eval()
            print("Text Fraud Detection Model loaded successfully")
        except Exception as e:
            print(f"Error loading text model: {e}")
            raise
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Analyze Arabic text for fraud/phishing detection
        
        Args:
            text: Arabic text message to analyze
            
        Returns:
            Dictionary containing classification results
        """
        try:
            if not text or not text.strip():
                return {
                    "success": False,
                    "error": "Empty text provided",
                    "is_fraud": False,
                    "confidence": 0.0,
                    "label": "unknown"
                }
            
            # Tokenize
            inputs = self.tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=512,
                padding=True
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Run inference
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=-1)
                predicted_class = torch.argmax(probs, dim=-1).item()
                confidence = probs[0][predicted_class].item()
            
            # Map prediction to label
            # Assuming binary classification: 0 = safe, 1 = fraud
            label_map = {
                0: "safe",
                1: "fraud"
            }
            
            predicted_label = label_map.get(predicted_class, "unknown")
            is_fraud = predicted_label == "fraud"
            
            return {
                "success": True,
                "label": predicted_label,
                "is_fraud": is_fraud,
                "confidence": confidence,
                "text_length": len(text),
                "reason": f"Text classified as {predicted_label} with {confidence:.2%} confidence"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "is_fraud": False,
                "confidence": 0.0,
                "label": "error",
                "reason": f"Error analyzing text: {str(e)}"
            }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call method"""
        text = state.get("text")
        if not text:
            return {
                **state,
                "text_result": {
                    "success": False,
                    "error": "No text provided",
                    "is_fraud": False,
                    "confidence": 0.0,
                    "label": "none"
                }
            }
        
        result = self.analyze(text)
        return {
            **state,
            "text_result": result
        }
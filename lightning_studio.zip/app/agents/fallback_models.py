"""
Fallback models and mock implementations for testing
Use these if the main models fail to load
"""

from typing import Dict, Any
import re

class FallbackTextAgent:
    """Fallback text fraud detector using rule-based approach"""
    
    def __init__(self):
        self.fraud_keywords = [
            'احتيال', 'نصب', 'تحويل', 'فوري', 'عاجل', 'جائزة', 
            'مجاني', 'اضغط هنا', 'رصيد', 'بطاقة', 'حساب',
            'password', 'urgent', 'click here', 'verify', 'suspended'
        ]
    
    def analyze(self, text: str) -> Dict[str, Any]:
        """Simple rule-based fraud detection"""
        if not text:
            return {
                "success": False,
                "error": "Empty text",
                "is_fraud": False,
                "confidence": 0.0,
                "label": "unknown"
            }
        
        text_lower = text.lower()
        fraud_score = 0
        matched_keywords = []
        
        for keyword in self.fraud_keywords:
            if keyword.lower() in text_lower:
                fraud_score += 1
                matched_keywords.append(keyword)
        
        # Check for URLs
        if re.search(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text):
            fraud_score += 1
            matched_keywords.append("URL_PRESENT")
        
        # Check for phone numbers
        if re.search(r'\d{10,}', text):
            fraud_score += 1
            matched_keywords.append("PHONE_NUMBER")
        
        is_fraud = fraud_score >= 2
        confidence = min(fraud_score / 5.0, 1.0)
        
        return {
            "success": True,
            "label": "fraud" if is_fraud else "safe",
            "is_fraud": is_fraud,
            "confidence": confidence,
            "text_length": len(text),
            "matched_keywords": matched_keywords,
            "reason": f"Text classified as {'fraud' if is_fraud else 'safe'} (matched {fraud_score} indicators)"
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call"""
        text = state.get("text")
        if not text:
            return {
                **state,
                "text_result": {
                    "success": False,
                    "error": "No text provided",
                    "is_fraud": False,
                    "confidence": 0.0,
                    "label": "none"
                }
            }
        
        result = self.analyze(text)
        return {
            **state,
            "text_result": result
        }

class FallbackUrlAgent:
    """Fallback URL safety checker using heuristics"""
    
    def __init__(self):
        self.suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz']
        self.trusted_domains = ['google.com', 'facebook.com', 'microsoft.com', 'apple.com', 'amazon.com']
    
    def analyze(self, url: str) -> Dict[str, Any]:
        """Simple heuristic-based URL analysis"""
        if not url:
            return {
                "success": False,
                "error": "Empty URL",
                "safe": True,
                "confidence": 0.0
            }
        
        risk_score = 0
        warning_flags = []
        
        # Check HTTPS
        if not url.startswith('https://'):
            risk_score += 1
            warning_flags.append("Not using HTTPS")
        
        # Check for IP address
        if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url):
            risk_score += 2
            warning_flags.append("URL contains IP address")
        
        # Check for @ symbol
        if '@' in url:
            risk_score += 2
            warning_flags.append("URL contains @ symbol")
        
        # Check suspicious TLDs
        if any(tld in url.lower() for tld in self.suspicious_tlds):
            risk_score += 2
            warning_flags.append("Suspicious top-level domain")
        
        # Check URL length
        if len(url) > 100:
            risk_score += 1
            warning_flags.append("Unusually long URL")
        
        # Check for trusted domains
        is_trusted = any(domain in url.lower() for domain in self.trusted_domains)
        if is_trusted:
            risk_score = max(0, risk_score - 2)
        
        is_safe = risk_score < 3
        confidence = 1.0 - (risk_score / 8.0)
        
        return {
            "success": True,
            "safe": is_safe,
            "confidence": max(0.0, confidence),
            "url": url,
            "warning_flags": warning_flags,
            "reason": f"URL classified as {'safe' if is_safe else 'malicious'} (risk score: {risk_score})"
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call"""
        url = state.get("url")
        if not url:
            return {
                **state,
                "url_result": {
                    "success": False,
                    "error": "No URL provided",
                    "safe": True,
                    "confidence": 0.0
                }
            }
        
        result = self.analyze(url)
        return {
            **state,
            "url_result": result
        }

class FallbackLogoAgent:
    """Fallback logo detector - basic image analysis"""
    
    def analyze(self, image_input: Any) -> Dict[str, Any]:
        """Basic image validation"""
        try:
            from PIL import Image
            import io
            
            if isinstance(image_input, bytes):
                image = Image.open(io.BytesIO(image_input))
            elif isinstance(image_input, str):
                image = Image.open(image_input)
            elif hasattr(image_input, 'size'):
                image = image_input
            else:
                raise ValueError("Invalid image input")
            
            # Basic checks
            width, height = image.size
            is_suspicious = False
            reason = "Basic image validation passed"
            
            if width < 50 or height < 50:
                is_suspicious = True
                reason = "Image too small to contain meaningful logo"
            elif width * height > 10000000:
                is_suspicious = True
                reason = "Unusually large image"
            
            return {
                "success": True,
                "detections": [],
                "total_detections": 0,
                "is_suspicious": is_suspicious,
                "confidence": 0.5,
                "reason": reason,
                "image_size": [width, height],
                "note": "Using fallback image validation (AI model not available)"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "is_suspicious": True,
                "confidence": 0.0,
                "reason": f"Error processing image: {str(e)}"
            }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call"""
        image_input = state.get("image")
        if image_input is None:
            return {
                **state,
                "logo_result": {
                    "success": False,
                    "error": "No image provided",
                    "is_suspicious": False,
                    "confidence": 0.0
                }
            }
        
        result = self.analyze(image_input)
        return {
            **state,
            "logo_result": result
        }
from typing import Dict, Any, List

class CoordinatorAgent:
    """
    Coordinator agent that decides which agents to call and synthesizes results
    """
    
    def __init__(self):
        self.risk_weights = {
            "logo": 0.3,
            "text": 0.4,
            "url": 0.3
        }
    
    def decide_agents(self, state: Dict[str, Any]) -> List[str]:
        """
        Decide which agents should be called based on input
        
        Returns:
            List of agent names to invoke
        """
        agents_to_call = []
        
        if state.get("text"):
            agents_to_call.append("text")
        
        if state.get("url"):
            agents_to_call.append("url")
        
        if state.get("image"):
            agents_to_call.append("logo")
        
        return agents_to_call
    
    def calculate_risk_score(self, state: Dict[str, Any]) -> float:
        """
        Calculate overall risk score from agent results
        
        Returns:
            Risk score between 0 (safe) and 1 (dangerous)
        """
        risk_score = 0.0
        total_weight = 0.0
        
        # Logo risk
        logo_result = state.get("logo_result", {})
        if logo_result.get("success"):
            logo_weight = self.risk_weights["logo"]
            if logo_result.get("is_suspicious"):
                risk_score += logo_result.get("confidence", 0.5) * logo_weight
            else:
                risk_score += (1 - logo_result.get("confidence", 0.5)) * logo_weight * 0.3
            total_weight += logo_weight
        
        # Text risk
        text_result = state.get("text_result", {})
        if text_result.get("success"):
            text_weight = self.risk_weights["text"]
            if text_result.get("is_fraud"):
                risk_score += text_result.get("confidence", 0.5) * text_weight
            else:
                risk_score += (1 - text_result.get("confidence", 0.5)) * text_weight * 0.2
            total_weight += text_weight
        
        # URL risk
        url_result = state.get("url_result", {})
        if url_result.get("success"):
            url_weight = self.risk_weights["url"]
            if not url_result.get("safe"):
                risk_score += url_result.get("confidence", 0.5) * url_weight
            else:
                risk_score += (1 - url_result.get("confidence", 0.5)) * url_weight * 0.2
            total_weight += url_weight
        
        # Normalize by total weight
        if total_weight > 0:
            risk_score = risk_score / total_weight
        
        return min(max(risk_score, 0.0), 1.0)
    
    def determine_final_decision(self, risk_score: float) -> str:
        """
        Determine final decision based on risk score
        
        Args:
            risk_score: Risk score between 0 and 1
            
        Returns:
            "safe", "suspicious", or "dangerous"
        """
        if risk_score < 0.3:
            return "safe"
        elif risk_score < 0.7:
            return "suspicious"
        else:
            return "dangerous"
    
    def generate_explanation(self, state: Dict[str, Any]) -> str:
        """
        Generate human-readable explanation of the analysis
        """
        explanations = []
        
        logo_result = state.get("logo_result", {})
        if logo_result.get("success"):
            if logo_result.get("is_suspicious"):
                explanations.append(f"⚠️ Logo Analysis: {logo_result.get('reason', 'Suspicious logo detected')}")
            else:
                explanations.append(f"✓ Logo Analysis: {logo_result.get('reason', 'Logo appears legitimate')}")
        
        text_result = state.get("text_result", {})
        if text_result.get("success"):
            if text_result.get("is_fraud"):
                explanations.append(f"⚠️ Text Analysis: {text_result.get('reason', 'Fraudulent text detected')}")
            else:
                explanations.append(f"✓ Text Analysis: {text_result.get('reason', 'Text appears safe')}")
        
        url_result = state.get("url_result", {})
        if url_result.get("success"):
            if not url_result.get("safe"):
                explanations.append(f"⚠️ URL Analysis: {url_result.get('reason', 'Malicious URL detected')}")
            else:
                explanations.append(f"✓ URL Analysis: {url_result.get('reason', 'URL appears safe')}")
        
        return "\n".join(explanations) if explanations else "No analysis performed"
    
    def synthesize(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Synthesize results from all agents
        """
        risk_score = self.calculate_risk_score(state)
        final_decision = self.determine_final_decision(risk_score)
        explanation = self.generate_explanation(state)
        
        return {
            **state,
            "risk_score": risk_score,
            "final_decision": final_decision,
            "explanation": explanation,
            "agents_called": self.decide_agents(state)
        }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call method"""
        return self.synthesize(state)
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from typing import Dict, Any
import re

class UrlAgent:
    def __init__(self):
        self.model_name = "Ruwad2/yaqith"
        self.tokenizer = None
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._load_model()
    
    def _load_model(self):
        """Load the URL safety detection model"""
        try:
            print(f"Loading URL Safety Detection Model: {self.model_name}")
            
            # Try loading with different configurations
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(
                    self.model_name,
                    trust_remote_code=True,
                    use_fast=True
                )
            except Exception as e1:
                print(f"Fast tokenizer failed, trying slow tokenizer: {e1}")
                try:
                    self.tokenizer = AutoTokenizer.from_pretrained(
                        self.model_name,
                        trust_remote_code=True,
                        use_fast=False
                    )
                except Exception as e2:
                    print(f"Slow tokenizer failed, using base BERT tokenizer: {e2}")
                    # Fallback to base BERT tokenizer
                    self.tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
            
            self.model = AutoModelForSequenceClassification.from_pretrained(
                self.model_name,
                trust_remote_code=True
            )
            self.model.to(self.device)
            self.model.eval()
            print("URL Safety Detection Model loaded successfully")
        except Exception as e:
            print(f"Error loading URL model: {e}")
            raise
    
    def _extract_features(self, url: str) -> Dict[str, Any]:
        """Extract heuristic features from URL"""
        features = {
            "length": len(url),
            "has_ip": bool(re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', url)),
            "has_at": '@' in url,
            "num_dots": url.count('.'),
            "num_hyphens": url.count('-'),
            "num_underscores": url.count('_'),
            "num_slashes": url.count('/'),
            "has_https": url.startswith('https://'),
            "suspicious_tld": any(tld in url.lower() for tld in ['.tk', '.ml', '.ga', '.cf', '.gq'])
        }
        return features
    
    def analyze(self, url: str) -> Dict[str, Any]:
        """
        Analyze URL for safety
        
        Args:
            url: URL to check
            
        Returns:
            Dictionary containing safety analysis
        """
        try:
            if not url or not url.strip():
                return {
                    "success": False,
                    "error": "Empty URL provided",
                    "safe": True,
                    "confidence": 0.0
                }
            
            # Extract heuristic features
            features = self._extract_features(url)
            
            # Tokenize URL
            inputs = self.tokenizer(
                url,
                return_tensors="pt",
                truncation=True,
                max_length=512,
                padding=True
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Run inference
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=-1)
                predicted_class = torch.argmax(probs, dim=-1).item()
                confidence = probs[0][predicted_class].item()
            
            # Map prediction to safety status
            # Assuming binary: 0 = safe, 1 = malicious
            is_safe = predicted_class == 0
            
            # Additional heuristic checks
            warning_flags = []
            if features["has_ip"]:
                warning_flags.append("URL contains IP address")
            if features["has_at"]:
                warning_flags.append("URL contains @ symbol")
            if features["suspicious_tld"]:
                warning_flags.append("Suspicious top-level domain")
            if features["length"] > 100:
                warning_flags.append("Unusually long URL")
            if not features["has_https"]:
                warning_flags.append("Not using HTTPS")
            
            # Adjust confidence based on heuristics
            if warning_flags and is_safe:
                confidence *= 0.8
            
            return {
                "success": True,
                "safe": is_safe,
                "confidence": confidence,
                "url": url,
                "features": features,
                "warning_flags": warning_flags,
                "reason": f"URL classified as {'safe' if is_safe else 'malicious'} with {confidence:.2%} confidence"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "safe": False,
                "confidence": 0.0,
                "reason": f"Error analyzing URL: {str(e)}"
            }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call method"""
        url = state.get("url")
        if not url:
            return {
                **state,
                "url_result": {
                    "success": False,
                    "error": "No URL provided",
                    "safe": True,
                    "confidence": 0.0
                }
            }
        
        result = self.analyze(url)
        return {
            **state,
            "url_result": result
        }
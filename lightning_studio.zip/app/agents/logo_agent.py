from transformers import AutoImageProcessor, AutoModelForObjectDetection
import torch
from PIL import Image
import numpy as np
from typing import Dict, Any, Optional
import io

class LogoAgent:
    def __init__(self):
        self.model_name = "Yasser18/detr-logodet3k"
        self.processor = None
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._load_model()
    
    def _load_model(self):
        """Load the logo detection model"""
        try:
            print(f"Loading Logo Detection Model: {self.model_name}")
            self.processor = AutoImageProcessor.from_pretrained(self.model_name)
            self.model = AutoModelForObjectDetection.from_pretrained(self.model_name)
            self.model.to(self.device)
            self.model.eval()
            print("Logo Detection Model loaded successfully")
        except Exception as e:
            print(f"Error loading logo model: {e}")
            raise
    
    def analyze(self, image_input: Any) -> Dict[str, Any]:
        """
        Analyze an image for logo detection
        
        Args:
            image_input: PIL Image, bytes, or file path
            
        Returns:
            Dictionary containing detection results
        """
        try:
            # Handle different input types
            if isinstance(image_input, bytes):
                image = Image.open(io.BytesIO(image_input)).convert("RGB")
            elif isinstance(image_input, str):
                image = Image.open(image_input).convert("RGB")
            elif isinstance(image_input, Image.Image):
                image = image_input.convert("RGB")
            else:
                raise ValueError("Invalid image input type")
            
            # Process image
            inputs = self.processor(images=image, return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Run inference
            with torch.no_grad():
                outputs = self.model(**inputs)
            
            # Post-process results
            target_sizes = torch.tensor([image.size[::-1]]).to(self.device)
            results = self.processor.post_process_object_detection(
                outputs, 
                target_sizes=target_sizes, 
                threshold=0.3
            )[0]
            
            # Extract detections
            detections = []
            max_confidence = 0.0
            
            for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
                score_val = score.item()
                label_val = label.item()
                box_val = box.tolist()
                
                if score_val > max_confidence:
                    max_confidence = score_val
                
                detections.append({
                    "box": box_val,
                    "confidence": score_val,
                    "label": self.model.config.id2label.get(label_val, f"label_{label_val}")
                })
            
            # Determine if suspicious
            # Logic: If confidence is low or multiple conflicting logos detected
            is_suspicious = False
            detection_reason = "No logos detected"
            
            if len(detections) == 0:
                is_suspicious = True
                detection_reason = "No recognizable logos found in image"
            elif len(detections) > 3:
                is_suspicious = True
                detection_reason = f"Multiple logos detected ({len(detections)}), possibly manipulated"
            elif max_confidence < 0.5:
                is_suspicious = True
                detection_reason = "Low confidence logo detection"
            else:
                detection_reason = f"{len(detections)} logo(s) detected with good confidence"
            
            return {
                "success": True,
                "detections": detections,
                "total_detections": len(detections),
                "is_suspicious": is_suspicious,
                "confidence": max_confidence,
                "reason": detection_reason,
                "image_size": list(image.size)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "is_suspicious": True,
                "confidence": 0.0,
                "reason": f"Error processing image: {str(e)}"
            }
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """LangGraph compatible call method"""
        image_input = state.get("image")
        if image_input is None:
            return {
                **state,
                "logo_result": {
                    "success": False,
                    "error": "No image provided",
                    "is_suspicious": False,
                    "confidence": 0.0
                }
            }
        
        result = self.analyze(image_input)
        return {
            **state,
            "logo_result": result
        }
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


class TextAnalysisRequest(BaseModel):
    text: str = Field(..., description="Text message to analyze")
    session_id: Optional[str] = Field(default="default", description="Session identifier")


class UrlAnalysisRequest(BaseModel):
    url: str = Field(..., description="URL to check")
    session_id: Optional[str] = Field(default="default", description="Session identifier")


class AllAnalysisRequest(BaseModel):
    text: Optional[str] = Field(None, description="Text message to analyze")
    url: Optional[str] = Field(None, description="URL to check")
    session_id: Optional[str] = Field(default="default", description="Session identifier")


class ChatRequest(BaseModel):
    message: str = Field(..., description="User message")
    url: Optional[str] = Field(None, description="Optional URL to analyze")
    session_id: Optional[str] = Field(default="default", description="Session identifier")


class DetectionBox(BaseModel):
    box: List[float]
    confidence: float
    label: str


class LogoResult(BaseModel):
    success: bool
    detections: Optional[List[DetectionBox]] = None
    total_detections: Optional[int] = None
    is_suspicious: bool
    confidence: float
    reason: str
    error: Optional[str] = None


class TextResult(BaseModel):
    success: bool
    label: Optional[str] = None
    is_fraud: bool
    confidence: float
    reason: str
    error: Optional[str] = None


class UrlResult(BaseModel):
    success: bool
    safe: bool
    confidence: float
    reason: str
    warning_flags: Optional[List[str]] = None
    error: Optional[str] = None


class AnalysisResponse(BaseModel):
    logo_result: Optional[Dict[str, Any]] = None
    text_result: Optional[Dict[str, Any]] = None
    url_result: Optional[Dict[str, Any]] = None
    final_decision: str = Field(..., description="Overall decision: safe, suspicious, or dangerous")
    risk_score: float = Field(..., description="Risk score between 0 and 1")
    explanation: str = Field(..., description="Human-readable explanation")
    session_id: str


class ChatResponse(BaseModel):
    message: str = Field(..., description="Bot response message")
    analysis: Optional[AnalysisResponse] = None
    session_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ChatHistoryItem(BaseModel):
    id: int
    user_message: str
    bot_response: str
    created_at: datetime


class ChatHistoryResponse(BaseModel):
    history: List[ChatHistoryItem]
    total: int


class HealthResponse(BaseModel):
    status: str
    models_loaded: Dict[str, bool]
    database_connected: bool
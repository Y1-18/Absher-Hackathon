﻿chrome.webNavigation.onCompleted.addListener(
  function (details) {
    let secure = details.url.startsWith("https://"); 
    if (secure) {
      chrome.tabs.create({ url: "popup.html" });
    }
  },
  { url: [{ urlMatches: ".*" }] }
);
